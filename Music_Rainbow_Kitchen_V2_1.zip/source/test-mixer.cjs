const fs=require('fs'),vm=require('vm'),assert=require('assert');
let id=0,tasks=new Map(),gainEvents=[],plays=0,pauses=0;const els=new Map();
function el(k){if(!els.has(k))els.set(k,{textContent:'',classList:{add(){},remove(){}},setAttribute(){},addEventListener(){},play(){plays++;return Promise.resolve()},pause(){pauses++}});return els.get(k);}
const context={currentTime:10,destination:{},createGain(){const gain={value:0,setValueAtTime(v,t){this.value=v;gainEvents.push([this,'set',v,t])},linearRampToValueAtTime(v,t){this.value=v;gainEvents.push([this,'ramp',v,t])},cancelAndHoldAtTime(){},cancelScheduledValues(){}};return {gain,connect(){}}},createMediaElementSource(){return {connect(){}}}};
const doc={getElementById:el,addEventListener(){},hidden:false};
const c=vm.createContext({document:doc,setTimeout(fn,ms){tasks.set(++id,{fn,ms});return id},clearTimeout(i){tasks.delete(i)},console});vm.runInContext(fs.readFileSync(__dirname+'/mixer.js','utf8'),c);const mix=c.KitchenMixer;
mix.init(context);mix.setActive(true);assert(plays>0);const note=mix.noteOutput();assert.equal(note.gain.value,.8);
mix.duck();assert.equal(gainEvents.at(-1)[2],0);assert.equal(gainEvents.at(-1)[3],10.045);
mix.holdUntil(13);assert.equal([...tasks.values()][0].ms,4000);
el('musicVolume').oninput({target:{value:'100'}});assert.equal(gainEvents.at(-1)[2],0,'volume changes cannot override ducking');
mix.release();assert.equal(tasks.size,1);assert.equal([...tasks.values()][0].ms,1000);
mix.duck();mix.holdUntil(14);assert.equal(tasks.size,1);assert.equal([...tasks.values()][0].ms,5000);
context.currentTime=15;let task=[...tasks.values()][0];tasks.clear();task.fn();assert.equal(gainEvents.at(-1)[2],1);
el('gameVolume').oninput({target:{value:'25'}});assert.equal(note.gain.value,.25);el('gameMute').onclick();assert.equal(note.gain.value,0);assert(mix.isMuted());el('gameMute').onclick();assert.equal(note.gain.value,.25);
el('musicMute').onclick();assert.equal(gainEvents.at(-1)[2],0);el('musicMute').onclick();assert.equal(gainEvents.at(-1)[2],1);
mix.duck();mix.holdUntil(18);mix.setActive(false);assert.equal(tasks.size,0);assert(pauses>0);assert.equal(gainEvents.at(-1)[2],0);
doc.hidden=true;mix.setActive(true);assert.equal(gainEvents.at(-1)[2],0);
console.log('PASS: 21 audio mixer assertions: duck-before-note timing, rapid replay, independent volume/mute, pause and hidden tab. Audio is mocked; physical listening not claimed.');
