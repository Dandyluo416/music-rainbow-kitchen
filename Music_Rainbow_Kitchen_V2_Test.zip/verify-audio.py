from pathlib import Path
import numpy as np,json
root=Path(__file__).parent
rate=22050;cases=[];features=[]
for i in range(12):
 for midi in range(57,77):
  a=np.fromfile(root/'audio-check-data'/f'{i}-{midi}.f32',dtype='<f4');f=440*2**((midi-69)/12)
  assert np.all(np.isfinite(a)) and abs(a[0])<1e-8 and abs(a[-1])<1e-6
  assert max(abs(a))<=.65001
  # Fundamental peak around expected frequency, interpolated with zero-padding.
  segment=a[int(.1*rate):int(.5*rate)];nfft=131072
  spectrum=abs(np.fft.rfft(segment*np.hanning(len(segment)),nfft));freqs=np.fft.rfftfreq(nfft,1/rate)
  lo,hi=np.searchsorted(freqs,[f*.97,f*1.03]);k=lo+np.argmax(spectrum[lo:hi]);y=np.log(np.maximum(spectrum[k-1:k+2],1e-20));delta=.5*(y[0]-y[2])/(y[0]-2*y[1]+y[2]);estimate=(k+delta)*rate/nfft;cents=1200*np.log2(estimate/f)
  assert abs(cents)<5,(i,midi,cents)
  cases.append({'instrument':i,'midi':midi,'target_hz':round(f,5),'measured_hz':round(estimate,5),'cents':round(cents,3)})
 a=np.fromfile(root/'audio-check-data'/f'{i}-69.f32',dtype='<f4')
 # Compare at identical pitch: harmonic spectral ratios plus normalized envelope bins.
 seg=a[:int(.57*rate)];sp=abs(np.fft.rfft(seg*np.hanning(len(seg)),131072));fr=np.fft.rfftfreq(131072,1/rate)
 h=np.array([max(sp[(fr>440*n-8)&(fr<440*n+8)]) for n in range(1,9)]);h=h/h[0]
 env=np.array([np.sqrt(np.mean(x*x)) for x in np.array_split(a,10)]);env/=max(env);features.append(np.r_[h,env])
distances=[float(np.linalg.norm(features[i]-features[j])) for i in range(12) for j in range(i+1,12)]
assert min(distances)>.1
report={'cases':len(cases),'max_pitch_error_cents':max(abs(c['cents']) for c in cases),'timbre_pairs':len(distances),'minimum_feature_distance':round(min(distances),4),'note':'Objective signal verification, not a human listening or physical-device test. Synthesized instrument approximations, not recorded instruments.','measurements':cases}
(root/'AUDIO_RESULTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='measurements'},ensure_ascii=False))
