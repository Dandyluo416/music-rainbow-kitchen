# 原創素材與製作提示

製作方式：內建 imagegen。以使用者先前提供的「音樂彩虹廚房大作戰」概念圖作為畫風參考；生成可拆用的環境、圖集，而非把概念圖當成互動畫面。四張 PNG 原檔均完整包入 `assets/`，以 CSS 圖集座標使用，未依賴外部圖片網址。生成圖像有細微不完全對齊的手繪差異，表情切換與裁切尚待瀏覽器視覺驗收。

## kitchen.png

Use case: stylized-concept. Production background for an original children's musical cooking game. Reference style: polished storybook cartoon rendering, warm outlined wood, glossy highlights, soft shadows, cheerful rainbow palette. Wide landscape 16:9. Cozy rainbow woodland kitchen with timber framing, large rainbow arch at upper left, herbs, hanging copper pans, sunlit windows, two warm pendant lamps, cream tiles, wooden countertop at lower edge. Detail concentrated at far edges and top 18%, quieter open cream wall in middle for HTML panels. No characters, food sprites, text, numbers, buttons, UI panels or note answers. Scenery only, not a game screenshot. Honey oak texture and dimensional lighting; new original scene.

## foods.png

Use case: stylized-concept. Transparent production food sprite atlas, 5 columns × 4 rows, equal cells. Rich hand-painted cartoon mobile game quality, warm brown outlines, juicy glossy highlights, soft shading. Center each icon with transparent padding; no grid, text, plates, UI or overlaps. Tiny cute smiling faces; clearly different silhouettes, consistent scale and lighting.

索引（先左至右，再上至下）與 `midi-57` 對應，順序不可改：

1. 蘋果、胡蘿蔔、草莓、檸檬、蘑菇。
2. 青花菜、葡萄、南瓜、茄子、西瓜。
3. 玉米、櫻桃、甜甜圈、布丁、餅乾。
4. 杯子蛋糕、起司、冰淇淋、牛奶、吐司。

## characters.png

Use case: stylized-concept. Transparent production animation atlas, 4 columns × 5 rows, equal square cells. Polished warm hand-painted chibi chef characters, dimensional shading, brown outlines, rosy cheeks. Full body centered at consistent scale with padding. Columns: honey brown bear with red neckerchief; cream bunny with pink bow; orange tabby cat with green neckerchief; navy and white penguin with blue bow. All wear white chef hats and cream aprons. Rows: relaxed open eyes; identical pose with eyes closed for blink; mildly worried waiting; joyful arms-up celebration; gentle puzzled encouragement with hand on cheek. No crying, text, grid, food, scenery or UI. Consistent identity and costume throughout.

CSS 表情列：0%＝待機、25%＝閉眼、50%＝緊張、75%＝歡呼、100%＝溫和困惑。以 transform 做呼吸／搖晃／跳躍，避免逐幀 JavaScript 重繪。

## props.png

Use case: stylized-concept. Transparent production UI prop atlas, 2 columns × 2 rows, equal cells. Warm hand-painted glossy storybook game art, honey brown outlines and dimensional highlights. Top left: empty cream ceramic serving plate with coral and gold double rim, slightly overhead, no food or face. Top right: blank honey oak wooden sign with carved frame, golden screws, wood grain, parchment center, no text. Bottom left: finished rainbow jelly with mint on a plate. Bottom right: embossed glowing golden reward star. No typography, characters, grid or scenery.

左上空盤用於訂單與未填空格；左下料理與右下星星用於成功動畫。右上木牌為可延伸備用素材，目前沒有作為互動控制項。

## 音效

音訊不是下載的錄音。`sound.js` 是原創的確定性加法合成器，採用逐諧波衰減、可調起音、持續段、餘弦釋放、部分輕微顫音／振幅調變。12 種模擬方向：木琴、長笛、單簧管、豎琴、弦樂、玻璃琴、手風琴、吉他、管風琴、巴松管、顫音琴、柔和鋼琴。所有正式音符皆由同一演算法產生；比較 WAV 也使用完全相同的合成器。
