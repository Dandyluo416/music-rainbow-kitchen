const fs=require('fs'),path=require('path'),K=require('./sound.js');
const rate=22050,notes=Array.from({length:20},(_,i)=>57+i),dir=path.join(__dirname,'audio-check-data');fs.mkdirSync(dir,{recursive:true});
for(let instrument=0;instrument<12;instrument++){
 for(const midi of notes){const a=K.synth(midi,instrument,rate);fs.writeFileSync(path.join(dir,`${instrument}-${midi}.f32`),Buffer.from(a.buffer));}
}
// Twelve instruments at the SAME A4 for fair timbre comparison; .5 s silent gaps.
let samples=[];for(let i=0;i<12;i++)samples.push(...K.synth(69,i,rate),...new Float32Array(rate*.5));
const b=Buffer.alloc(44+samples.length*2);b.write('RIFF');b.writeUInt32LE(b.length-8,4);b.write('WAVEfmt ',8);b.writeUInt32LE(16,16);b.writeUInt16LE(1,20);b.writeUInt16LE(1,22);b.writeUInt32LE(rate,24);b.writeUInt32LE(rate*2,28);b.writeUInt16LE(2,32);b.writeUInt16LE(16,34);b.write('data',36);b.writeUInt32LE(samples.length*2,40);samples.forEach((x,i)=>b.writeInt16LE(Math.round(x*32767),44+i*2));fs.writeFileSync(path.join(__dirname,'assets','instrument-audition.wav'),b);
console.log('Rendered 240 waveform cases and 12-instrument same-pitch WAV.');
