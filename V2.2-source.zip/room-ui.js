/* Multiplayer adapter around the existing single-device game. No teacher console. */
(function(){
'use strict';
const base={renderBenches,renderKitchen,undo:$('undo').onclick,clear:$('clear').onclick,playBuilt:$('playBuilt').onclick,endRound,back};
let client=null,active=false,busy=false,uiTimer=null,lastPhase='',lastRound='',selectedOrder=null,closedHints=new Set(),endedShown=false;
function error(e){const msg=String(e?.message||e);const denied=/permission|denied/i.test(msg);$('roomMessage').textContent=denied?'Firebase 目前拒絕存取。請先依說明發布 V2.2 安全規則；也請確認房號、位置與房間期限。':msg;if(active)feedback(denied?'連線權限未就緒，請查看安全規則說明。':msg);}
function makeClient(){const c=new KitchenRoomClient(window.KITCHEN_FIREBASE_CONFIG,KitchenRoomGame);c.onError=error;c.onState=applyState;c.onRoster=renderRoster;c.onConnection=()=>{renderRoster();decorate();};c.onPending=p=>{busy=p;decorate();};c.onClosed=()=>{closeLocal();$('roomMessage').textContent='房間已關閉，單機模式仍可使用。';};return c;}
async function enter(kind){if(active)return;const buttons=[$('roomCreate'),$('roomJoin'),$('roomReconnect')];buttons.forEach(b=>b.disabled=true);try{
 await unlock();client=makeClient();const count=Number($('roomLocalCount').value);$('roomMessage').textContent='正在以匿名身分連線…';
 if(kind==='create')await client.create({...config},count);else{let code=$('roomCodeInput').value;if(kind==='reconnect'){const saved=JSON.parse(sessionStorage.getItem('rainbow-v22-room')||'null');if(!saved)throw Error('沒有可恢復的房間');code=saved.code;}await client.join(code,count);}
 active=true;document.body.classList.add('multiplayer');$('roomBar').classList.remove('hidden');$('roomMessage').textContent='';
 clearInterval(timer);uiTimer=setInterval(tickRoom,100);renderRoster();if(client.game)applyState(client.game);
 }catch(e){client?.disconnect();client=null;active=false;error(e);}finally{buttons.forEach(b=>b.disabled=false);}
}
function closeLocal(){active=false;clearInterval(uiTimer);client?.disconnect();client=null;busy=false;document.body.classList.remove('multiplayer');$('roomBar').classList.add('hidden');$('roomLobby').classList.add('hidden');base.back();}
async function leave(){try{await client.leave();closeLocal();}catch(e){error(e);}}
function roster(){return Object.entries(client?.members||{}).sort((a,b)=>a[1].device-b[1].device);}
function renderRoster(){if(!active||!client)return;const entries=roster(),count=entries.reduce((n,[,m])=>n+m.count,0),cfg=client.game?.config||config;
 $('roomCodeDisplay').textContent=client.code;$('roomBarCode').textContent=client.code;$('roomRoster').innerHTML=entries.map(([uid,m])=>`<div class="room-member"><b>裝置 ${m.device+1}${uid===client.uid?'（這一台）':''}${uid===client.hostUid?' · 房主':''}</b><span>廚師 ${m.first+1}${m.second>=0?'、'+(m.second+1):''}</span><span>${client.presence[uid]?.connected?'已連線':'暫離'}${client.game?.phase==='prep'&&m.readyRound===client.game.roundId?' · 已準備':''}</span></div>`).join('');
 $('roomLobbySummary').textContent=`${count}／${cfg.players} 位廚師 · ${entries.length}／4 台裝置 · ${MODES[cfg.mode].name}`;
 $('roomPrepare').disabled=!client.host||count!==cfg.players||!KitchenRoomGame.rosterOK(client.game||{config:cfg},client.context())||busy;
 $('roomPrepare').textContent=client.host?'人到齊了，開始備料':'等待房主開始備料';
 const own=client.members[client.uid];$('roomConnection').textContent=!client.connected?'網路中斷，等待重連':!client.hostAvailable()?'等待房主恢復連線':`你是廚師 ${own?own.first+1:'…'}${own?.second>=0?'、'+(own.second+1):''}${client.host?' · 房主':''}${busy?' · 同步中':''}`;
 if(client.game?.phase==='prep'){const ready=own?.readyRound===client.game.roundId,all=roster().every(([,m])=>m.readyRound===client.game.roundId);$('openShop').textContent=client.host&&all?'全員準備好了，開始營業！':ready?'已準備，等待夥伴':'這台準備好了！';$('openShop').disabled=busy||(ready&&!(client.host&&all));}
}
function applyState(g){if(!client)return;client.game=g;if(!active)return;const oldScore=state?.score||0,oldSelected=state?.selected,oldOrder=state?.active,oldBuilt=state?.orders?.find(o=>o.id===oldOrder)?.built.length||0;
 if(lastRound!==g.roundId){closedHints.clear();endedShown=false;selectedOrder=null;lastRound=g.roundId;}
 config={...g.config};state={...g,ingredients:g.ingredients.map(n=>({...byMidi(n.midi),owner:n.owner})),orders:g.orders.map(o=>({...o,built:[...o.built],recipeOpen:o.hinted&&!closedHints.has(o.id)})),selected:oldSelected??null};
 state.active=state.orders.some(o=>o.id===oldOrder)?oldOrder:state.orders[0]?.id;state.selected=state.ingredients.some(n=>n.midi===state.selected&&client.owns(n.owner))?state.selected:null;
 const phaseChanged=lastPhase!==g.phase;lastPhase=g.phase;
 for(const [id,phase] of [['setup','never'],['roomLobby','lobby'],['prep','prep'],['game','playing']])$(id).classList.toggle('hidden',g.phase!==phase&&(id!=='game'||g.phase!=='ended'));
 if(g.phase==='lobby'){stopAudio();KitchenMixer.setActive(false);$('overlay').classList.add('hidden');renderRoster();return;}
 const ownCount=client.members[client.uid]?.count||1;
 if(g.phase==='prep'){$('overlay').classList.add('hidden');$('prepSummary').textContent=`房間 ${client.code} · ${config.players} 位廚師 · ${MODES[config.mode].name}`;$('prepBenches').className='benches prep-benches '+config.mode;$('prepBenches').style.setProperty('--players',ownCount);$('prepBenches').style.setProperty('--per',MODES[config.mode].per);renderBenches('prepBenches');$('prepStatus').textContent='只顯示這台負責的食材；不計時，可以反覆試聽。';KitchenMixer.setActive(client.host);}
 else{$('game').classList.remove('many');$('benches').className='benches '+config.mode;$('benches').style.setProperty('--players',ownCount);$('benches').style.setProperty('--per',MODES[config.mode].per);$('orders').style.setProperty('--orders',MODES[config.mode].cap);renderBenches();renderOrders();renderKitchen();stats();if(current()?.id===oldOrder&&current().built.length>oldBuilt)$('plate').children[current().built.length-1]?.classList.add('arriving');
  if(g.phase==='ended'){if(!endedShown){endedShown=true;base.endRound();}}else if(g.paused){stopAudio();KitchenMixer.setActive(false);$('overlay').classList.remove('hidden');$('modal').innerHTML='<h2>廚房休息一下</h2><p>回合時間與客人的耐心都已暫停。</p><div class="modal-actions"><button class="primary" data-action="resume">繼續料理</button><button data-action="settings">離開房間</button></div>';}else{$('overlay').classList.add('hidden');KitchenMixer.setActive(client.host);}
 }
 feedback(g.message||'一起合作料理！',g.score>oldScore);renderRoster();decorate();tickRoom();
 // Only the host has access to the actual unhinted answer and plays order requests.
 if(client.host&&g.audio?.id&&client.lastAudio!==g.audio.id){client.lastAudio=g.audio.id;if(!g.paused&&client.now()-g.audio.at<5000){const privateGame=client.authority&&JSON.parse(client.authority.game),order=privateGame?.orders.find(o=>o.id===g.audio.orderId);if(order)play(order.answer);}}
}
function renderOwn(target='benches'){if(!active)return base.renderBenches(target);$(target).innerHTML=Array.from({length:config.players},(_,i)=>i).filter(i=>client.owns(i)).map(i=>`<section class="bench" style="--color:${COLORS[i]};--tint:${TINTS[i]}"><h3>${i+1} 號廚師</h3><div class="ingredients">${state.ingredients.filter(n=>n.owner===i).map(n=>`<button class="ingredient" data-midi="${n.midi}" aria-label="${i+1} 號廚師，${n.name}，${n.sol} ${n.oct}" aria-pressed="${state.selected===n.midi}">${food(n.id)}<span class="label">${label(n.midi)}<small class="food-name">${n.name}</small></span></button>`).join('')}</div></section>`).join('');}
function usableRoom(){if(!active||!state||state.phase!=='playing'||state.paused||state.ended)return false;if(!client.hostAvailable()||busy){feedback(busy?'上一個操作正在同步，請稍候':'等待房主裝置恢復連線');return false;}return true;}
function decorate(){if(!active||!state)return;const enabled=state.phase==='playing'&&!state.paused&&!state.ended&&client.hostAvailable()&&!busy;for(const id of ['listen','recipe','undo','clear','serve','confirm']){const b=$(id);if(!enabled)b.disabled=true;}if(enabled){const o=current();if(o){$('listen').disabled=$('recipe').disabled=false;$('undo').disabled=$('clear').disabled=!o.built.length;$('confirm').disabled=state.selected===null||o.built.length>=o.len;$('serve').disabled=o.built.length!==o.len||!o.heard;}}
 for(const b of document.querySelectorAll('[data-listen]'))b.disabled=!enabled;}
async function send(type,orderId=current()?.id??-1,midi=-1){if(!active)return;try{await client.command(type,orderId,midi,current()?.editRevision||0);}catch(e){error(e);}finally{renderRoster();if(state?.phase==='playing'){renderKitchen();decorate();}}}
function confirm(){if(!usableRoom()||state.selected===null)return;const midi=state.selected;state.selected=null;renderBenches();renderKitchen();send('add',current().id,midi);}
function hint(){if(!usableRoom())return;const o=current();if(o.hinted){if(closedHints.has(o.id))closedHints.delete(o.id);else closedHints.add(o.id);o.recipeOpen=!closedHints.has(o.id);renderKitchen();}else send('hint');}
function effectiveNow(){if(!client)return performance.now();return client.hostAvailable()?client.now():Math.min(client.now(),client.public?.hostBeat||client.now());}
function tickRoom(){if(!active||!state)return;renderRoster();decorate();if(state.phase==='playing'){const now=state.paused?state.pauseAt:effectiveNow(),remain=Math.max(0,Math.ceil((state.end-now)/1000));$('clock').textContent=`${Math.floor(remain/60)}:${String(remain%60).padStart(2,'0')}`;$('clockBox').classList.toggle('urgent',remain<=30);updateBars(now);}}
async function ready(){if(!active)return;try{await unlock();const own=client.members[client.uid];if(own?.readyRound!==state.roundId)await client.ready(state.roundId);else if(client.host)await send('begin',-1);}catch(e){error(e);}}
function visibility(){if(!active)return;if(document.hidden){stopAudio();KitchenMixer.setActive(false);if(client.host&&state?.phase==='playing'&&!state.paused)send('pause');}else{client.markPresence().catch(error);if(client.host)client.heartbeat();KitchenMixer.setActive(client.host&&state?.phase!=='lobby'&&!state?.paused&&!state?.ended);}}
window.KitchenRoomUI={get active(){return active;},owns:i=>client?.owns(i),renderBenches:renderOwn,usable:usableRoom,tick:tickRoom,now:effectiveNow,send,confirm,hint,ready,visibility,leave,decorate};
$('roomCreate').onclick=()=>enter('create');$('roomJoin').onclick=()=>enter('join');$('roomReconnect').onclick=()=>enter('reconnect');$('roomPrepare').onclick=()=>send('prepare',-1);$('roomLeave').onclick=leave;
$('undo').onclick=()=>active?send('undo'):base.undo();$('clear').onclick=()=>active?send('clear'):base.clear();
const openShop=$('openShop').onclick;$('openShop').onclick=()=>active?ready():openShop();
renderKitchen=function(){base.renderKitchen();decorate();};
try{$('roomReconnect').classList.toggle('hidden',!sessionStorage.getItem('rainbow-v22-room'));}catch{}
})();
