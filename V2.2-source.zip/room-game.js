/* Deterministic host referee. Transaction retries never choose a new random answer. */
(function(root){
'use strict';
const MODES={easy:{per:2,min:2,max:3,cap:1,patience:65000},normal:{per:3,min:3,max:4,cap:2,patience:85000},hard:{per:4,min:4,max:5,cap:3,patience:105000}};
const NAT=[57,59,60,62,64,65,67,69,71,72,74,76];
const dishes=['星光小點心','彩虹午餐','雲朵特餐','森林派對餐','微笑分享盤','月亮好滋味'];
const clone=v=>JSON.parse(JSON.stringify(v));
function random(g){let x=g.rng|0;x^=x<<13;x^=x>>>17;x^=x<<5;g.rng=x>>>0;return g.rng/4294967296;}
function shuffle(g,a){a=[...a];for(let i=a.length-1;i;i--){let j=Math.floor(random(g)*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
function validConfig(c){return !!MODES[c?.mode]&&Number.isInteger(c.players)&&c.players>=1&&c.players<=Math.min(6,Math.floor((c.mode==='hard'?20:12)/MODES[c.mode].per))&&[120,180,300].includes(c.seconds)&&['sol','note','both'].includes(c.display);}
function initial(config,seed){if(!validConfig(config))throw Error('無效設定');return {config:clone(config),rng:seed||1234567,phase:'lobby',roundId:'lobby',ingredients:[],orders:[],turn:0,serial:0,score:0,success:0,wrong:0,expired:0,combo:0,best:0,paused:false,ended:false,message:'等待夥伴加入',revision:0};}
function ingredients(g){const {players,mode}=g.config,per=MODES[mode].per,n=players*per,src=mode==='hard'?Array.from({length:20},(_,i)=>i+57):NAT;
 const windows=Array.from({length:src.length-n+1},(_,i)=>src.slice(i,i+n)),central=windows.filter(w=>w[0]>=60&&w.at(-1)<=72),best=Math.min(...windows.map(w=>Math.abs((w[0]+w.at(-1))/2-66)));
 const choices=central.length?central:windows.filter(w=>Math.abs((w[0]+w.at(-1))/2-66)<=best+1),notes=choices[Math.floor(random(g)*choices.length)],owners=shuffle(g,Array.from({length:players},(_,i)=>i));
 const groups=Array.from({length:players},(_,i)=>mode==='easy'?notes.slice(i*per,(i+1)*per):[]);
 if(mode!=='easy')for(let b=0;b<per;b++)shuffle(g,notes.slice(b*players,(b+1)*players)).forEach((m,i)=>groups[i].push(m));
 return groups.flatMap((a,i)=>a.sort((a,b)=>a-b).map(midi=>({midi,owner:owners[i]})));
}
function fill(g,now){const mode=MODES[g.config.mode];while(g.orders.length<mode.cap){const len=mode.min+Math.floor(random(g)*(mode.max-mode.min+1)),answer=[];for(let i=0;i<len;i++){const owner=g.turn++%g.config.players,a=g.ingredients.filter(n=>n.owner===owner);answer.push(a[Math.floor(random(g)*a.length)].midi);}g.orders.push({id:++g.serial,len,answer,customer:Math.floor(random(g)*4),dish:dishes[Math.floor(random(g)*dishes.length)],created:now,deadline:now+mode.patience,patience:mode.patience,built:[],contributors:[],attempts:0,heard:false,hinted:false,recipeOpen:false,status:'waiting'});}}
function rosterOK(g,ctx){const entries=Object.entries(ctx.members||{});return entries.length>=1&&entries.length<=4&&entries.every(([uid,m])=>ctx.presence?.[uid]?.connected&&ctx.seats?.[m.first]===uid&&(m.count===1||ctx.seats?.[m.second]===uid))&&Object.keys(ctx.seats||{}).length===g.config.players&&Array.from({length:g.config.players},(_,i)=>ctx.seats[i]).every(Boolean);}
function shift(g,delta){if(g.end)g.end+=delta;for(const o of g.orders){o.deadline+=delta;o.created+=delta;}}
function advance(g,now){if(g.phase!=='playing'||g.paused)return;if(now>=g.end){g.phase='ended';g.ended=true;g.message='打烊囉！廚師們辛苦了';return;}const dead=g.orders.filter(o=>o.deadline<=now);if(dead.length){g.expired+=dead.length;g.combo=0;g.orders=g.orders.filter(o=>o.deadline>now);g.message='客人先去散步了，新訂單繼續加油！';fill(g,now);}}
function publicState(g){const v=clone(g);delete v.rng;v.orders.forEach(o=>{if(!o.hinted)delete o.answer;});return v;}
function sanitizePublic(g,config){if(!validConfig(config)||!['lobby','prep','playing','ended'].includes(g?.phase)||!Array.isArray(g.ingredients)||!Array.isArray(g.orders)||g.orders.length>3)throw Error('房間資料格式不正確');
 for(const key of ['score','success','wrong','expired','combo','best'])if(!Number.isInteger(g[key])||g[key]<0||g[key]>100000000)throw Error('房間成績資料不正確');
 g.config=clone(config);for(const n of g.ingredients)if(!Number.isInteger(n.midi)||n.midi<57||n.midi>76||!Number.isInteger(n.owner)||n.owner<0||n.owner>=config.players)throw Error('食材音高資料不正確');
 for(const o of g.orders){if(!Number.isInteger(o.id)||o.id<1||o.id>=100000||!Number.isInteger(o.len)||o.len<2||o.len>5||!Array.isArray(o.built)||o.built.length>o.len||!o.built.every(m=>Number.isInteger(m)&&m>=57&&m<=76))throw Error('訂單資料不正確');o.dish=dishes.includes(o.dish)?o.dish:'旋律料理';o.customer=Number.isInteger(o.customer)&&o.customer>=0&&o.customer<=3?o.customer:0;if(o.hinted&&(!Array.isArray(o.answer)||o.answer.length!==o.len||!o.answer.every(m=>Number.isInteger(m)&&m>=57&&m<=76)))throw Error('食譜資料不正確');if(!o.hinted)delete o.answer;}
 return g;
}
function reduce(input,cmd,ctx,now){const g=clone(input),isHost=cmd.uid===ctx.hostUid,member=ctx.members?.[cmd.uid];let result='ok';
 const reject=text=>({game:g,result:text,changed:false});
 if(!member)return reject('你尚未加入房間');
 if(cmd.type!=='tick'&&now-cmd.createdAt>30000)return reject('這個操作等待太久，請確認料理後重新操作');
 if(g.phase==='playing'&&g.lastHostAt&&now-g.lastHostAt>8000&&!g.paused){shift(g,now-g.lastHostAt);g.message='房主已重新連線，回合時間已保留';}
 advance(g,now);g.lastHostAt=now;
 if(cmd.type==='tick'){g.revision++;return {game:g,result,changed:true};}
 if(['prepare','restart'].includes(cmd.type)){
  if(!isHost)return reject('請由房主開始備料');
  if(!['lobby','ended'].includes(g.phase)||!rosterOK(g,ctx))return reject('請等所有廚師與裝置加入並連線');
  g.phase='prep';g.roundId='r'+(g.revision+1)+'-'+now;g.ingredients=ingredients(g);g.orders=[];g.turn=0;g.score=g.success=g.wrong=g.expired=g.combo=g.best=0;g.paused=g.ended=false;delete g.end;g.message='先認識自己的食材，再按準備好了';
 }else if(cmd.type==='begin'){
  if(!isHost||g.phase!=='prep'||!rosterOK(g,ctx)||!Object.values(ctx.members).every(m=>m.readyRound===g.roundId))return reject('等每台裝置按下準備好了');
  g.phase='playing';g.end=now+g.config.seconds*1000;fill(g,now);g.message='開始營業！先聽訂單，再一起放食材';
 }else{
  if(cmd.roundId!==g.roundId)return reject('這是上一回合的操作，沒有套用');
  if(cmd.type==='pause'&&g.phase==='playing'&&!g.paused){g.paused=true;g.pauseAt=now;g.message='夥伴暫停了廚房';}
  else if(cmd.type==='resume'&&g.phase==='playing'&&g.paused){shift(g,now-g.pauseAt);g.paused=false;g.message='繼續料理！';}
  else{
   if(g.phase!=='playing'||g.paused)return reject('請等待回合開始或恢復');
   const o=g.orders.find(o=>o.id===cmd.orderId);if(!o)return reject('這張訂單已離開；操作沒有放進新訂單');
   if(cmd.type==='add'){
    if(!g.ingredients.some(n=>n.midi===cmd.midi&&(member.first===n.owner||member.second===n.owner)))return reject('只能放入自己負責的食材');
    if(o.built.length>=o.len)return reject('料理盤已滿，食材沒有加入');
    o.built.push(cmd.midi);o.contributors.push(cmd.uid);g.message='已放入第 '+o.built.length+' 個食材';
   }else if(cmd.type==='undo'||cmd.type==='clear'){
    // Revision guards prevent an old clear/undo from erasing a partner's new contribution.
    if(cmd.orderRevision!==o.editRevision)return reject('夥伴剛修改了這張訂單，請查看後再操作');
    if(cmd.type==='undo'){o.built.pop();o.contributors.pop();}else{o.built=[];o.contributors=[];}g.message='已修改料理';
   }else if(cmd.type==='hint'){o.hinted=true;o.recipeOpen=true;g.message='此單已使用食譜，完成得分 ×70%';}
   else if(cmd.type==='listen'){o.heard=true;g.audio={id:cmd.id,orderId:o.id,at:now};g.message='請聽房主裝置播放的旋律';}
   else if(cmd.type==='serve'){
    if(!o.heard||o.built.length!==o.len)return reject('請先聽音並填滿料理盤');
    if(cmd.orderRevision!==o.editRevision)return reject('料理剛被修改，請確認後再出餐');
    o.attempts++;
    if(o.answer.every((m,i)=>o.built[i]===m)){g.combo++;g.best=Math.max(g.best,g.combo);const points=Math.round((100+(o.attempts===1?20:0)+Math.max(0,Math.min(20,Math.floor(20*(o.deadline-now)/o.patience)))+Math.min(30,(g.combo-1)*5))*(o.hinted?.7:1));g.score+=points;g.success++;g.orders=g.orders.filter(x=>x.id!==o.id);fill(g,now);g.message='★ 好吃！＋'+points+' 分';}
    else{g.wrong++;g.combo=0;g.message='再試一次！可以修改後再出餐';}
   }else return reject('不支援的操作');
   if(g.orders.includes(o))o.editRevision=(o.editRevision||0)+1;
  }
 }
 g.revision++;return {game:g,result,changed:true};
}
function transact(authority,cmd,ctx,now){if(!authority)return;const a=clone(authority),last=a.processed?.[cmd.uid];if(last&&cmd.seq<=last.seq)return a;
 const r=reduce(JSON.parse(a.game),cmd,ctx,now);a.game=JSON.stringify(r.game);a.revision=r.game.revision;a.processed??={};a.processed[cmd.uid]={id:cmd.id,seq:cmd.seq,result:r.result,revision:a.revision};return a;
}
root.KitchenRoomGame={initial,reduce,transact,publicState,sanitizePublic,validConfig,rosterOK,MODES};if(typeof module!=='undefined')module.exports=root.KitchenRoomGame;
})(typeof globalThis!=='undefined'?globalThis:this);
