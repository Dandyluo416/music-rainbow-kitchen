const fs=require('fs'),path=require('path'),cp=require('child_process');
const root=__dirname,out=path.join(root,'../github-v2.2');fs.mkdirSync(out,{recursive:true});
let html=fs.readFileSync(path.join(root,'index.html'),'utf8');
html=html.replace(/<link rel="stylesheet" href="([^"]+)">/g,(_,p)=>'<style>'+fs.readFileSync(path.join(root,p),'utf8')+'</style>');
html=html.replace(/<script src="([^"]+)"><\/script>/g,(_,p)=>'<script>'+fs.readFileSync(path.join(root,p),'utf8').replace(/<\/script/gi,'<\\/script')+'</script>');
for(const name of ['kitchen','foods','characters','props'])html=html.split('assets/'+name+'.png').join('data:image/png;base64,'+fs.readFileSync(path.join(root,'assets',name+'.png')).toString('base64'));
html=html.split('assets/enchanted-forest-kitchen.m4a').join('data:audio/mp4;base64,'+fs.readFileSync(path.join(root,'assets/enchanted-forest-kitchen.m4a')).toString('base64'));
html=html.replace(/<a href="audio-lab.html"[^>]*>.*?<\/a>/g,'<a href="v2.2-setup.html" target="_blank" rel="noopener">多人連線設定說明</a>');
for(const m of html.matchAll(/<script>([\s\S]*?)<\/script>/g)){const r=cp.spawnSync(process.execPath,['--check'],{input:m[1],encoding:'utf8'});if(r.status)throw Error(r.stderr);}
fs.writeFileSync(path.join(out,'v2.2-preview.html'),html);
const rules=fs.readFileSync(path.join(root,'firebase-database.rules.json'),'utf8');JSON.parse(rules);
fs.writeFileSync(path.join(out,'v2.2-rules.json'),rules);
let guide=fs.readFileSync(path.join(root,'FIREBASE_SETUP.html'),'utf8').replace('RULES_JSON_HERE',rules.replace(/&/g,'&amp;').replace(/</g,'&lt;'));
fs.writeFileSync(path.join(out,'v2.2-setup.html'),guide);
console.log('Built independent V2.2 preview:',Buffer.byteLength(html),'bytes; production index.html untouched.');
