var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// room-transport.entry.js
var room_transport_entry_exports = {};
__export(room_transport_entry_exports, {
  RoomClient: () => RoomClient
});
module.exports = __toCommonJS(room_transport_entry_exports);
var import_app = require("firebase/app");
var import_auth = require("firebase/auth");
var import_database = require("firebase/database");
var RoomClient = class {
  constructor(config, game) {
    this.config = config;
    this.Game = game;
    this.off = [];
    this.connected = false;
    this.members = {};
    this.presence = {};
    this.seats = {};
    this.offset = 0;
    this.seq = Date.now() * 1e3;
    this.lastAudio = "";
    this.pumping = false;
  }
  now() {
    return Date.now() + this.offset;
  }
  async init() {
    if (this.uid) return;
    const app = (0, import_app.initializeApp)(this.config, "rainbow-v22");
    const auth = (0, import_auth.getAuth)(app);
    await (0, import_auth.setPersistence)(auth, import_auth.browserSessionPersistence);
    await auth.authStateReady();
    this.uid = (auth.currentUser || (await (0, import_auth.signInAnonymously)(auth)).user).uid;
    this.db = (0, import_database.getDatabase)(app);
    this.off.push((0, import_database.onValue)((0, import_database.ref)(this.db, ".info/serverTimeOffset"), (s) => this.offset = s.val() || 0));
    this.off.push((0, import_database.onValue)((0, import_database.ref)(this.db, ".info/connected"), (s) => {
      this.connected = !!s.val();
      this.onConnection?.(this.connected);
      if (this.connected && this.code) this.markPresence().catch((e) => this.onError?.(e));
    }));
  }
  path(p = "") {
    return (0, import_database.ref)(this.db, "roomsV22/" + this.code + (p ? "/" + p : ""));
  }
  async create(config, count) {
    await this.init();
    if (!this.Game.validConfig(config)) throw Error("\u4EBA\u6578\u6216\u96E3\u5EA6\u8D85\u904E\u97F3\u57DF\u5BB9\u91CF");
    if (count > config.players) throw Error("\u672C\u6A5F\u4EBA\u6578\u8D85\u904E\u623F\u9593\u7E3D\u4EBA\u6578");
    const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789", bytes = crypto.getRandomValues(new Uint8Array(6));
    this.code = [...bytes].map((n) => alphabet[n % alphabet.length]).join("");
    this.hostUid = this.uid;
    const now = this.now(), game = this.Game.initial(config, crypto.getRandomValues(new Uint32Array(1))[0]);
    game.lastHostAt = now;
    this.expiresAt = now + 719e4;
    const member = { device: 0, count, first: 0, second: count === 2 ? 1 : -1, joinedAt: now, readyRound: "none" }, seats = { 0: this.uid };
    if (count === 2) seats[1] = this.uid;
    const room = { meta: { hostUid: this.uid, createdAt: now, expiresAt: now + 719e4, config, version: "2.2" }, members: { [this.uid]: member }, seats, deviceSlots: { 0: this.uid }, authority: { revision: 0, game: JSON.stringify(game) }, public: this.pack(game) };
    this.roomConfig = config;
    await (0, import_database.set)(this.path(), room);
    await this.attach();
    return this.code;
  }
  pack(game) {
    return { phase: game.phase, roundId: game.roundId, revision: game.revision, snapshot: JSON.stringify(this.Game.publicState(game)), hostBeat: game.lastHostAt || this.now() };
  }
  async join(code, count) {
    await this.init();
    code = code.trim().toUpperCase();
    if (!/^[A-HJ-NP-Z2-9]{6}$/.test(code)) throw Error("\u8ACB\u8F38\u5165\u516D\u78BC\u623F\u9593\u4EE3\u865F");
    this.code = code;
    const meta = (await (0, import_database.get)(this.path("meta"))).val();
    if (!meta || meta.expiresAt <= this.now()) throw Error("\u623F\u9593\u4E0D\u5B58\u5728\u6216\u5DF2\u904E\u671F");
    this.hostUid = meta.hostUid;
    this.expiresAt = meta.expiresAt;
    this.roomConfig = meta.config;
    const existing = (await (0, import_database.get)(this.path("members/" + this.uid)).catch(() => null))?.val();
    if (!existing) {
      const seats = (await (0, import_database.get)(this.path("seats"))).val() || {}, devices = (await (0, import_database.get)(this.path("deviceSlots"))).val() || {}, device = [0, 1, 2, 3].find((i) => !devices[i]), free = Array.from({ length: meta.config.players }, (_, i) => i).filter((i) => !seats[i]);
      if (device === void 0) throw Error("\u623F\u9593\u6700\u591A\u56DB\u53F0\u88DD\u7F6E");
      if (free.length < count) throw Error("\u5269\u9918\u5EDA\u5E2B\u4F4D\u7F6E\u4E0D\u8DB3");
      const first = free[0], second = count === 2 ? free[1] : -1, changes = { ["members/" + this.uid]: { device, count, first, second, joinedAt: this.now(), readyRound: "none" }, ["deviceSlots/" + device]: this.uid, ["seats/" + first]: this.uid };
      if (second >= 0) changes["seats/" + second] = this.uid;
      await (0, import_database.update)(this.path(), changes);
    }
    await this.attach();
  }
  async attach() {
    this.host = this.uid === this.hostUid;
    const [members, seats, presence] = await Promise.all(["members", "seats", "presence"].map((p) => (0, import_database.get)(this.path(p))));
    this.members = members.val() || {};
    this.seats = seats.val() || {};
    this.presence = presence.val() || {};
    sessionStorage.setItem("rainbow-v22-room", JSON.stringify({ code: this.code, uid: this.uid }));
    const watch = (p, fn) => this.off.push((0, import_database.onValue)(this.path(p), (s) => fn(s.val()), (e) => {
      if (/permission|denied/i.test(String(e?.message)) && !this.closed) {
        this.closed = true;
        this.onClosed?.();
      } else if (!this.closed) this.onError?.(e);
    }));
    watch("members", (v) => {
      this.members = v || {};
      this.onRoster?.();
    });
    watch("presence", (v) => {
      this.presence = v || {};
      this.onRoster?.();
    });
    watch("seats", (v) => {
      this.seats = v || {};
      this.onRoster?.();
    });
    watch("public", (v) => {
      if (!v) {
        this.onClosed?.();
        return;
      }
      try {
        this.public = v;
        this.game = this.Game.sanitizePublic(JSON.parse(v.snapshot), this.roomConfig);
        this.onState?.(this.game);
      } catch (e) {
        this.onError?.(e);
      }
    });
    watch("receipts/" + this.uid, (v) => {
      this.receipt = v;
      if (v) this.seq = Math.max(this.seq, v.seq);
      this.settlePending();
    });
    watch("requests/" + this.uid, (v) => {
      this.ownRequest = v;
      this.settlePending();
    });
    if (this.host) {
      watch("requests", (v) => {
        this.requests = v || {};
        this.pump();
      });
      watch("authority", (v) => {
        this.authority = v;
      });
      this.hostTimer = setInterval(() => this.heartbeat(), 2e3);
    }
    this.expiryTimer = setTimeout(() => {
      this.onError?.(Error("\u623F\u9593\u5DF2\u5230\u5169\u5C0F\u6642\u671F\u9650\uFF0C\u8ACB\u91CD\u65B0\u958B\u623F"));
      this.disconnect();
    }, Math.max(0, this.expiresAt - this.now()));
    await this.markPresence();
    const saved = sessionStorage.getItem("rainbow-v22-pending");
    if (saved) {
      try {
        const cmd = JSON.parse(saved);
        if (cmd.code === this.code) {
          delete cmd.code;
          this.pending = cmd;
          this.onPending?.(true);
          const receipt = (await (0, import_database.get)(this.path("receipts/" + this.uid))).val();
          if (receipt?.id === cmd.id) {
            this.pending = null;
            sessionStorage.removeItem("rainbow-v22-pending");
            this.onPending?.(false);
          } else if (!(await (0, import_database.get)(this.path("requests/" + this.uid))).exists()) {
            this.pending = null;
            sessionStorage.removeItem("rainbow-v22-pending");
            this.onPending?.(false);
            this.onError?.(Error("\u672A\u5B8C\u6210\u7684\u64CD\u4F5C\u5DF2\u53D6\u6D88\uFF0C\u8ACB\u78BA\u8A8D\u6599\u7406\u5F8C\u91CD\u65B0\u64CD\u4F5C"));
          }
        }
      } catch {
        sessionStorage.removeItem("rainbow-v22-pending");
      }
    }
  }
  settlePending() {
    const v = this.receipt;
    if (!v || this.ownRequest !== null || this.pending?.id !== v.id) return;
    const pending = this.pending;
    this.pending = null;
    sessionStorage.removeItem("rainbow-v22-pending");
    this.onPending?.(false);
    if (v.result === "ok") pending.resolve?.(v);
    else pending.reject?.(Error(v.result));
  }
  async markPresence() {
    if (!this.code || !this.uid || !this.connected || !this.members[this.uid]) return;
    await (0, import_database.onDisconnect)(this.path("presence/" + this.uid)).set({ connected: false, seenAt: (0, import_database.serverTimestamp)() });
    await (0, import_database.set)(this.path("presence/" + this.uid), { connected: true, seenAt: (0, import_database.serverTimestamp)() });
  }
  owns(owner) {
    const m = this.members[this.uid];
    return !!m && (m.first === owner || m.second === owner);
  }
  hostAvailable() {
    return this.connected && !!this.presence[this.hostUid]?.connected && !!this.public && this.now() - this.public.hostBeat < 1e4;
  }
  async ready(roundId) {
    if (!this.connected) throw Error("\u7DB2\u8DEF\u5C1A\u672A\u9023\u7DDA");
    await (0, import_database.set)(this.path("members/" + this.uid + "/readyRound"), roundId);
  }
  command(type, orderId = -1, midi = -1, orderRevision = 0) {
    if (!this.hostAvailable()) return Promise.reject(Error("\u7B49\u5F85\u623F\u4E3B\u88DD\u7F6E\u6062\u5FA9\u9023\u7DDA"));
    if (this.pending) return Promise.reject(Error("\u4E0A\u4E00\u500B\u64CD\u4F5C\u4ECD\u5728\u540C\u6B65\uFF0C\u8ACB\u7A0D\u5019"));
    const cmd = { id: crypto.randomUUID(), seq: this.seq = Math.max(this.seq + 1, Date.now() * 1e3), uid: this.uid, type, roundId: this.game?.roundId || "lobby", orderId, midi, orderRevision, createdAt: this.now() };
    return new Promise((resolve, reject) => {
      this.pending = { ...cmd, resolve, reject };
      sessionStorage.setItem("rainbow-v22-pending", JSON.stringify({ ...cmd, code: this.code }));
      this.onPending?.(true);
      (0, import_database.set)(this.path("requests/" + this.uid), cmd).catch((e) => {
        if (this.pending?.id === cmd.id) {
          this.pending = null;
          sessionStorage.removeItem("rainbow-v22-pending");
          this.onPending?.(false);
          reject(e);
        }
      });
    });
  }
  context() {
    return { hostUid: this.hostUid, members: this.members, seats: this.seats, presence: this.presence };
  }
  async publish(a, cmd) {
    this.authority = a;
    const game = JSON.parse(a.game), changes = { public: this.pack(game) };
    if (cmd) {
      const receipt = a.processed?.[cmd.uid];
      if (receipt) changes["receipts/" + cmd.uid] = receipt.id === cmd.id ? receipt : { id: cmd.id, seq: cmd.seq, result: "\u8F03\u820A\u7684\u64CD\u4F5C\u5DF2\u5FFD\u7565\uFF0C\u8ACB\u78BA\u8A8D\u76EE\u524D\u6599\u7406", revision: a.revision };
    }
    await (0, import_database.update)(this.path(), changes);
    if (cmd) await (0, import_database.runTransaction)(this.path("requests/" + cmd.uid), (r) => r?.id === cmd.id ? null : void 0, { applyLocally: false });
  }
  async pump() {
    if (!this.host || this.pumping || !this.connected) return;
    this.pumping = true;
    try {
      for (const cmd of Object.values(this.requests || {}).sort((a, b) => a.createdAt - b.createdAt || a.id.localeCompare(b.id))) {
        const context = this.context(), now = this.now();
        const result = await (0, import_database.runTransaction)(this.path("authority"), (a) => a ? this.Game.transact(a, cmd, context, now) : a, { applyLocally: false });
        if (result.committed && result.snapshot.exists()) await this.publish(result.snapshot.val(), cmd);
      }
    } catch (e) {
      this.onError?.(e);
    } finally {
      this.pumping = false;
      if (Object.keys(this.requests || {}).length && this.code) queueMicrotask(() => this.pump());
    }
  }
  async heartbeat() {
    if (!this.host || !this.connected || this.pumping || typeof document !== "undefined" && document.hidden) return;
    this.pumping = true;
    try {
      const now = this.now(), context = this.context();
      const result = await (0, import_database.runTransaction)(this.path("authority"), (a) => {
        if (!a) return a;
        const game = JSON.parse(a.game), r = this.Game.reduce(game, { uid: this.uid, type: "tick" }, context, now);
        return { ...a, revision: r.game.revision, game: JSON.stringify(r.game) };
      }, { applyLocally: false });
      if (result.committed && result.snapshot.exists()) await this.publish(result.snapshot.val());
    } catch (e) {
      this.onError?.(e);
    } finally {
      this.pumping = false;
      this.pump();
    }
  }
  async leave() {
    if (!this.code) return;
    if (this.host) {
      await (0, import_database.remove)(this.path());
    } else if (this.game?.phase === "lobby") {
      const m = this.members[this.uid], changes = { ["members/" + this.uid]: null, ["presence/" + this.uid]: null };
      if (m) {
        changes["seats/" + m.first] = null;
        changes["deviceSlots/" + m.device] = null;
        if (m.second >= 0) changes["seats/" + m.second] = null;
      }
      await (0, import_database.update)(this.path(), changes);
    } else {
      await (0, import_database.set)(this.path("presence/" + this.uid), { connected: false, seenAt: (0, import_database.serverTimestamp)() });
    }
    sessionStorage.removeItem("rainbow-v22-room");
    sessionStorage.removeItem("rainbow-v22-pending");
    this.disconnect();
  }
  disconnect() {
    for (const off of this.off) off();
    this.off = [];
    clearInterval(this.hostTimer);
    clearTimeout(this.expiryTimer);
    this.code = null;
  }
};
window.KitchenRoomClient = RoomClient;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  RoomClient
});
