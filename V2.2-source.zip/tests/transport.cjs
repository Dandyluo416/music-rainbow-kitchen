const fs=require('fs'),assert=require('node:assert/strict');
global.window={};const store=new Map();global.sessionStorage={getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)};
const {initializeTestEnvironment}=require('@firebase/rules-unit-testing');const {ref,get,set,update,goOffline,goOnline}=require('firebase/database');
const {RoomClient}=require('./transport-node.cjs'),G=require('../room-game.js');
const wait=async(fn,label)=>{for(let i=0;i<200;i++){if(fn())return;await new Promise(r=>setTimeout(r,40));}throw Error('Timed out: '+label);};
let checks=0,clients=[],env;const timeout=setTimeout(()=>{console.error('Integration test timeout');process.exit(1);},60000);
(async()=>{
env=await initializeTestEnvironment({projectId:'demo-rainbow-v22',database:{host:'127.0.0.1',port:9000,rules:fs.readFileSync(__dirname+'/../firebase-database.rules.json','utf8')}});await env.clearDatabase();
function device(uid){const c=new RoomClient({},G);c.uid=uid;c.db=env.authenticatedContext(uid).database();c.connected=true;c.onError=e=>console.error('device',uid,e.message);clients.push(c);return c;}
const h=device('host'),g=device('guest');await h.create({players:4,mode:'easy',seconds:120,display:'sol'},2);await wait(()=>h.hostAvailable(),'host ready');store.clear();await g.join(h.code,2);await wait(()=>Object.keys(h.members).length===2&&h.presence.guest?.connected,'both joined');
assert.equal(g.members.guest.count,2);checks++;console.log('integration: joined');
await h.command('prepare');await wait(()=>g.game?.phase==='prep','shared prep');assert.equal(g.game.ingredients.length,8);checks++;console.log('integration: prep');
await Promise.all([h.ready(h.game.roundId),g.ready(g.game.roundId)]);await wait(()=>Object.values(h.members).every(m=>m.readyRound===h.game.roundId),'ready acknowledgements');await h.command('begin');await wait(()=>g.game.phase==='playing','shared start');
assert(!g.game.orders[0].answer);checks++;console.log('integration: playing');const orderId=h.game.orders[0].id;
await g.command('listen',orderId);await wait(()=>h.game.orders[0].heard&&g.game.orders[0].heard,'host handles guest listen');console.log('integration: listened');
const answer=JSON.parse(h.authority.game).orders[0].answer;
// Two devices submit together; the referee retains both, in order, without last-writer overwrite.
const hm=h.game.ingredients.find(n=>n.owner===h.members.host.first).midi,gm=g.game.ingredients.find(n=>n.owner===g.members.guest.first).midi;
await Promise.all([h.command('add',orderId,hm),g.command('add',orderId,gm)]);await wait(()=>g.game.orders[0].built.length===2,'concurrent inserts');assert.deepEqual([...g.game.orders[0].built].sort(),[hm,gm].sort());checks++;console.log('integration: concurrent adds');
await h.command('clear',orderId,-1,h.game.orders[0].editRevision);await wait(()=>!g.game.orders[0].built.length,'clear shared');
for(const midi of answer){const owner=h.game.ingredients.find(n=>n.midi===midi).owner,c=h.owns(owner)?h:g;await c.command('add',orderId,midi,c.game.orders[0].editRevision);}
await wait(()=>h.game.orders[0].built.length===answer.length,'filled');await h.command('hint',orderId);await wait(()=>g.game.orders[0].answer?.length>0,'hint shared');await g.command('serve',orderId,-1,g.game.orders[0].editRevision);await wait(()=>h.game.success===1&&g.game.success===1,'score synchronization');assert(h.game.score>=70&&h.game.score<=98);checks++;console.log('integration: score');
// Replay the committed action under its original identifier. It must not score twice.
const committed=(await get(h.path('receipts/guest'))).val(),before=h.game.score;
await set(g.path('requests/guest'),{...committed,uid:'guest',type:'serve',roundId:g.game.roundId,orderId,orderRevision:0,midi:-1,createdAt:g.now(),result:null,revision:null});
await wait(()=>!h.requests.guest,'duplicate drained');assert.equal(h.game.score,before);checks++;
await h.command('pause',-1);await wait(()=>g.game.paused,'pause synchronized');const end=h.game.end;await new Promise(r=>setTimeout(r,200));await g.command('resume',-1);await wait(()=>!h.game.paused,'resume synchronized');assert(h.game.end>end);checks++;
// Actual SDK disconnect invokes the registered server-side presence update.
goOffline(g.db);g.connected=false;await wait(()=>h.presence.guest?.connected===false,'disconnect presence');goOnline(g.db);g.connected=true;await g.markPresence();await wait(()=>h.presence.guest?.connected===true,'reconnect presence');assert.equal(g.members.guest.first,2);checks++;
let closed=false;g.onClosed=()=>{closed=true;g.disconnect();};await h.leave();await wait(()=>closed,'close propagation');checks++;g.disconnect();console.log('PASS:',checks,'actual Firebase Web SDK + emulator integration checks across two independent clients.');
for(const c of clients)c.disconnect();await env.cleanup();clearTimeout(timeout);
})().catch(async e=>{console.error(e);for(const c of clients)c.disconnect();await env?.cleanup();clearTimeout(timeout);process.exitCode=1;});
