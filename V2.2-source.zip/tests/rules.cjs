const fs=require('fs'),assert=require('node:assert/strict');
const {initializeTestEnvironment,assertSucceeds,assertFails}=require('@firebase/rules-unit-testing');
const {ref,set,get,update,remove}=require('firebase/database');
const G=require('../room-game.js');
let checks=0;const timeout=setTimeout(()=>{console.error('Local emulator test timeout after check',checks);process.exit(1);},45000);const yes=async p=>{await assertSucceeds(p);checks++;},no=async p=>{await assertFails(p);checks++;};
(async()=>{
const env=await initializeTestEnvironment({projectId:'demo-rainbow-v22',database:{host:'127.0.0.1',port:9000,rules:fs.readFileSync(__dirname+'/../firebase-database.rules.json','utf8')}});
await env.clearDatabase();const host=env.authenticatedContext('host').database(),guest=env.authenticatedContext('guest').database(),other=env.authenticatedContext('other').database(),anon=env.unauthenticatedContext().database();const code='ABC234',p='roomsV22/'+code,now=Date.now(),config={players:4,mode:'easy',seconds:120,display:'sol'},game=G.initial(config,42);game.lastHostAt=now;
const member=(device,first,second=-1)=>({device,count:second<0?1:2,first,second,joinedAt:now,readyRound:'none'});
const room={meta:{hostUid:'host',createdAt:now,expiresAt:now+600000,version:'2.2',config},members:{host:member(0,0,1)},seats:{0:'host',1:'host'},deviceSlots:{0:'host'},authority:{revision:0,game:JSON.stringify(game)},public:{phase:'lobby',roundId:'lobby',revision:0,snapshot:JSON.stringify(G.publicState(game)),hostBeat:now}};
await no(set(ref(anon,p),room));await yes(set(ref(host,p),room));
await no(get(ref(guest,'roomsV22')));await no(get(ref(anon,p+'/meta')));await yes(get(ref(guest,p+'/meta')));await no(get(ref(guest,p+'/public')));await no(get(ref(guest,p+'/authority')));
await no(set(ref(guest,p+'/members/guest'),member(1,2,3))); // atomic seat/device claim required
await yes(update(ref(guest,p),{'members/guest':member(1,2,3),'seats/2':'guest','seats/3':'guest','deviceSlots/1':'guest'}));
await yes(get(ref(guest,p+'/public')));await yes(get(ref(guest,p+'/members')));
await no(set(ref(guest,p+'/seats/0'),'guest'));await no(set(ref(guest,p+'/public/snapshot'),'hacked'));
await no(set(ref(guest,p+'/authority/game'),'hacked'));await no(update(ref(guest,p+'/meta'),{hostUid:'guest'}));
await no(set(ref(guest,p+'/members/host/readyRound'),'fake'));await yes(set(ref(guest,p+'/members/guest/readyRound'),'r1'));
await no(set(ref(guest,p+'/members/guest/first'),0));await no(set(ref(other,p+'/members/other'),member(2,5)));
await yes(set(ref(guest,p+'/presence/guest'),{connected:true,seenAt:now}));await no(set(ref(guest,p+'/presence/host'),{connected:false,seenAt:now}));
let cmd={id:'test-op-123',seq:1,uid:'guest',type:'add',roundId:'r1',orderId:1,orderRevision:0,midi:60,createdAt:now};
await no(set(ref(guest,p+'/requests/host'),cmd));await no(set(ref(guest,p+'/requests/guest'),{...cmd,type:'setScore'}));
await yes(set(ref(guest,p+'/requests/guest'),cmd));await no(set(ref(guest,p+'/requests/guest'),{...cmd,id:'replacement'}));
await yes(get(ref(host,p+'/requests')));await no(get(ref(other,p+'/requests')));await no(get(ref(other,p+'/requests/guest')));
await no(set(ref(guest,p+'/receipts/guest'),{id:cmd.id,seq:1,result:'ok',revision:1}));
await yes(update(ref(host,p),{'requests/guest':null,'receipts/guest':{id:cmd.id,seq:1,result:'ok',revision:1}}));
await yes(get(ref(guest,p+'/receipts/guest')));await no(get(ref(other,p+'/receipts/guest')));
await yes(set(ref(host,p+'/public/phase'),'playing'));
await no(update(ref(other,p),{'members/other':member(2,2),'seats/2':'other','deviceSlots/2':'other'}));
await no(remove(ref(guest,p)));await yes(remove(ref(host,p)));
// Concurrent joins claiming the same free seat/device: exactly one wins atomically.
room.meta.createdAt=Date.now();room.meta.expiresAt=Date.now()+600000;await yes(set(ref(host,p),room));
const join=(db,uid)=>update(ref(db,p),{['members/'+uid]:member(1,2),['seats/2']:uid,'deviceSlots/1':uid});
const results=await Promise.allSettled([join(guest,'guest'),join(other,'other')]);assert.equal(results.filter(r=>r.status==='fulfilled').length,1);checks++;
console.log('PASS:',checks,'Firebase emulator security assertions, including atomic concurrent joins.');
await env.cleanup();clearTimeout(timeout);
})().catch(e=>{console.error(e);process.exitCode=1;});
