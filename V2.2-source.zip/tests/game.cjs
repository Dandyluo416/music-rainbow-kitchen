const assert=require('node:assert/strict'),G=require('../room-game.js');let count=0;const check=(v,m)=>{assert(v,m);count++;};
let now=100000,seq=0;const context={hostUid:'h',members:{h:{count:2,first:0,second:1,readyRound:'none'},g:{count:2,first:2,second:3,readyRound:'none'}},seats:{0:'h',1:'h',2:'g',3:'g'},presence:{h:{connected:true},g:{connected:true}}};
function command(type,extras={}){return {id:'op-'+(++seq),seq,uid:'h',type,roundId:game.roundId,createdAt:now,orderId:game.orders[0]?.id||-1,orderRevision:game.orders[0]?.editRevision||0,...extras};}
let game=G.initial({players:4,mode:'easy',seconds:120,display:'sol'},42),a={revision:0,game:JSON.stringify(game)};
function apply(cmd){a=G.transact(a,cmd,context,now);game=JSON.parse(a.game);return a.processed[cmd.uid].result;}
check(apply(command('prepare'))==='ok','prepare');check(game.phase==='prep'&&!game.orders.length&&!game.end,'prep does not tick');
check(game.ingredients.length===8&&game.ingredients.every(n=>n.midi>=60&&n.midi<=72),'compact range');
for(let owner=0;owner<4;owner++){const p=game.ingredients.filter(n=>n.owner===owner);check(p.length===2&&Math.abs(p[0].midi-p[1].midi)<=2,'nearby simple notes');}
check(apply(command('begin'))!=='ok','not ready');for(const m of Object.values(context.members))m.readyRound=game.roundId;
check(apply(command('begin'))==='ok'&&game.phase==='playing','begin all ready');check(!('answer' in G.publicState(game).orders[0]),'answer private');
let o=game.orders[0],target=o.id;check(apply(command('listen'))==='ok','listen');
// Two partners at the same public revision add without overwriting.
let notes=[...o.answer];for(const midi of notes){const owner=game.ingredients.find(n=>n.midi===midi).owner,uid=owner<2?'h':'g';check(apply(command('add',{uid,midi,orderId:target}))==='ok','owner add');}
check(game.orders[0].built.length===notes.length,'all contributions preserved');
let serve=command('serve');check(apply(serve)==='ok'&&game.success===1,'serve');let score=game.score;apply(serve);check(game.score===score&&game.success===1,'same id and sequence cannot rescore');
check(apply(command('add',{orderId:target,midi:notes[0]}))!=='ok','late order rejected');
let own=game.ingredients.find(n=>n.owner===0).midi,foreign=game.ingredients.find(n=>n.owner===2).midi;
check(apply(command('add',{uid:'h',midi:foreign}))!=='ok','foreign ingredient denied');
let stale=command('clear');apply(command('add',{midi:own}));apply(stale);check(game.orders[0].built.length===1&&a.processed.h.seq>stale.seq,'old sequence cannot erase new contribution');
let staleRevision=command('clear',{orderRevision:0});check(apply(staleRevision)!=='ok'&&game.orders[0].built.length===1,'old clear revision cannot erase new contribution');
apply(command('hint'));check(game.orders[0].hinted&&G.publicState(game).orders[0].answer.length>0,'hint publishes staff pitches');
check(apply(command('add',{midi:own,roundId:'old-round'}))!=='ok','old round denied');
let end=game.end;apply(command('pause'));now+=15000;apply(command('resume'));check(game.end===end+15000,'pause preserves time');
end=game.end;now+=20000;apply(command('tick'));check(game.end===end+20000,'host reconnect preserves missed interval');
const oldEnd=game.end;now=oldEnd+1;game.lastHostAt=now-1000;a.game=JSON.stringify(game);apply(command('tick'));check(game.ended&&game.phase==='ended','round ends');
apply(command('restart'));check(game.phase==='prep'&&game.score===0&&game.success===0&&!game.orders.length,'independent replay');
for(const mode of ['easy','normal','hard'])for(let players=1;players<=6;players++){const cfg={players,mode,seconds:120,display:'sol'};if(!G.validConfig(cfg))continue;for(let seed=1;seed<=30;seed++){let g=G.initial(cfg,seed),members={},presence={},seats={};for(let i=0;i<players;i++){const uid='p'+Math.floor(i/2);members[uid]??={count:0,first:i,second:-1};const m=members[uid];m.count++;if(m.count===2)m.second=i;seats[i]=uid;presence[uid]={connected:true};}const c={hostUid:'p0',members,presence,seats};g=G.reduce(g,{uid:'p0',type:'prepare',createdAt:now},c,now).game;for(const m of Object.values(members))m.readyRound=g.roundId;g=G.reduce(g,{uid:'p0',type:'begin',createdAt:now},c,now).game;check(g.orders.every(o=>o.answer.every(m=>g.ingredients.some(n=>n.midi===m))),'all random orders solvable');}}
console.log('PASS:',count,'room-referee assertions: ownership, concurrency, deduplication, stale actions, host reconnect and random modes.');
