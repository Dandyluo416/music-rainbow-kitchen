const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(__dirname+'/index.html','utf8'),script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
let time=1000;const els=new Map();function el(id){if(!els.has(id))els.set(id,{innerHTML:'',textContent:'',value:'',disabled:false,dataset:{},closest(){return null},setAttribute(){},addEventListener(){},play(){return Promise.resolve()},pause(){},children:[],style:{setProperty(){},transform:''},classList:{add(){},remove(){},toggle(){}},matches(){return false}});return els.get(id)}
let scheduled=[];class AudioMock{constructor(){this.state='running';this.currentTime=0;this.destination={}}resume(){return Promise.resolve()}createMediaElementSource(){return {connect(){}}}createBuffer(ch,len,rate){const data=new Float32Array(len);return {duration:len/rate,getChannelData:()=>data}}createBufferSource(){const o={connect(){},disconnect(){},start(t){o.startAt=t;scheduled.push(o)},stop(t){o.stopAt=t}};return o}createGain(){return {gain:{cancelScheduledValues(){},setValueAtTime(){},linearRampToValueAtTime(){},exponentialRampToValueAtTime(){}},connect(){},disconnect(){}}}}
const c=vm.createContext({document:{getElementById:el,addEventListener(){},documentElement:{}},window:{AudioContext:AudioMock},performance:{now:()=>time},setInterval:()=>1,clearInterval(){},setTimeout:()=>1,clearTimeout(){},KitchenNotation:{render:(ms)=>'<svg>'+ms.map(m=>'<g data-staff-midi="'+m+'"></g>').join('')+'</svg>'},console,Float32Array});
vm.runInContext(fs.readFileSync(__dirname+'/sound.js','utf8'),c);vm.runInContext(fs.readFileSync(__dirname+'/mixer.js','utf8'),c);vm.runInContext(script,c);const run=s=>vm.runInContext(s,c);let checks=0;function check(s){assert(run(s),s);checks++}
(async()=>{
for(const mode of ['easy','normal','hard'])for(let n=1;n<=7;n++){
run(`config={players:${n},mode:'${mode}',seconds:120,display:'sol'}`);const valid=n*run(`MODES['${mode}'].per`) <=(mode==='hard'?20:12);check(`(pool(${n},'${mode}')!==null)===${valid}`);if(!valid)continue;
run('startRound();beginTrading()');check(`state.ingredients.length===${n}*MODES['${mode}'].per`);check('new Set(state.ingredients.map(n=>n.midi)).size===state.ingredients.length');check('state.ingredients.every(n=>n.midi>=57&&n.midi<=76)');check('Array.from({length:config.players},(_,i)=>state.ingredients.filter(n=>n.owner===i).length).every(n=>n===MODES[config.mode].per)');if(mode!=='hard')check('state.ingredients.every(n=>NAT.includes(n.midi))');
for(let j=0;j<100;j++){check('(()=>{const o=makeOrder(performance.now());return o.answer.length>=MODES[config.mode].min&&o.answer.length<=MODES[config.mode].max&&o.answer.every(m=>state.ingredients.some(n=>n.midi===m))&&new Set(o.answer.map(m=>state.ingredients.find(n=>n.midi===m).owner)).size===Math.min(config.players,o.len)})()');}
}
run("config={players:4,mode:'hard',seconds:180,display:'both'};startRound();beginTrading()");check('state.ingredients.length===16&&state.ingredients.at(-1).midi-state.ingredients[0].midi<=15');check('Math.abs(byMidi(69).freq-440)<1e-10');check('NOTES.every((n,i)=>n.id===i&&n.name===FOOD_NAMES[i]&&Math.abs(n.freq-440*2**((n.midi-69)/12))<1e-10)');
run('choose(state.ingredients[0].midi)');check('current().built.length===0');run('add();choose(state.ingredients[0].midi);add()');check('current().built.length===2&&current().built[0]===current().built[1]');run('globalThis.savedId=state.active;globalThis.savedBuilt=JSON.stringify(current().built);selectOrder(state.orders[1].id);choose(state.ingredients[1].midi);add();selectOrder(savedId)');check('JSON.stringify(current().built)===savedBuilt');check('state.selected===null');
run('current().answer=[57,59,60,62];current().len=4;current().built=[];renderOrders();renderKitchen()');check("!$('orders').innerHTML.includes('data-midi')&&!$('orders').innerHTML.includes('<sub>')&&!$('orders').innerHTML.includes('蘋果')");check("!$('plate').innerHTML.includes('#atlas-foods')&&$('plate').innerHTML.includes('empty-plate')");
run('current().built=[57,57,57,57];current().heard=true;submit()');check('state.score===0&&state.wrong===1&&current().built.length===4&&state.combo===0');run('current().built=[57,59,60,62];submit()');check('state.success===1&&state.combo===1&&state.score>=100&&state.score<=120');
run('current().heard=true;current().built=[...current().answer];submit()');check('state.success===2&&state.combo===2&&state.best===2');
run('globalThis.before=state.end;pause()');time+=10000;run('resume()');check('state.end===before+10000');run('current().deadline=performance.now()-1;tick()');check('state.expired===1&&state.combo===0&&state.orders.length===3');
run('state.end=performance.now()-1;tick()');check('state.ended');run('startRound();beginTrading()');check('state.score===0&&state.success===0&&state.wrong===0&&state.expired===0&&state.combo===0');run('back()');check('state===null');run('startRound();beginTrading()');check('state.orders.length===3');
// Prep has no orders/timer and does not lose its distribution on opening.
run('startRound();globalThis.prepMap=JSON.stringify(state.ingredients)');check("state.phase==='prep'&&state.orders.length===0&&state.end===undefined");time+=200000;run('tick()');check("state.phase==='prep'&&state.score===0&&state.orders.length===0");await run('audition(state.ingredients[0].midi)');check('state.orders.length===0');run('beginTrading()');check('JSON.stringify(state.ingredients)===prepMap');check('state.end===performance.now()+config.seconds*1000');
// Unheard orders cannot be submitted; confirmed repeat ingredients are supported.
run('current().built=[...current().answer];submit()');check('state.success===0');await run('listen(state.active)');check('current().heard');run('submit()');check('state.success===1');
run('choose(state.ingredients[0].midi);add();choose(state.ingredients[0].midi);add();$("undo").onclick()');check('current().built.length===1');run('$("clear").onclick()');check('current().built.length===0');
// Audio buffers are immutable, cancel previous sequences and share the same mapping.
await run('unlock()');scheduled=[];await run('play([69,72,76])');assert.equal(scheduled.length,3);assert(scheduled[0].stopAt<scheduled[1].startAt);checks+=2;const old=scheduled.slice();await run('play([60])');assert(old.every(o=>o.stopAt===.013));checks++;check('voices.length===1');
run("config.mode='easy'");scheduled=[];await run('play([57,59])');assert.notDeepEqual(scheduled[0].buffer.getChannelData(0),scheduled[1].buffer.getChannelData(0));checks++;const original=scheduled[0].buffer;scheduled=[];await run('play([57])');assert.strictEqual(scheduled[0].buffer,original);checks++;
check("new Set(NAT.map(m=>KitchenSound.instrument(m,'easy'))).size===12");check("NOTES.every(n=>KitchenSound.instrument(n.midi,'normal')===11&&KitchenSound.instrument(n.midi,'hard')===11)");
await Promise.all([run('play([57,59,60])'),run('play([69])')]);check('voices.length===1');
// End, back and replay are independent, and returning to prep cancels audio.
run('state.end=performance.now()-1;tick();startRound()');check("state.phase==='prep'&&state.score===0&&state.combo===0&&state.orders.length===0&&voices.length===0");run('back()');check('state===null');
// Compact windows, changing assignments, and per-chef difficulty progression.
for(let j=0;j<100;j++){
run("config={players:4,mode:'easy',seconds:180,display:'sol'};startRound()");
check('state.ingredients.every(n=>n.midi>=60&&n.midi<=72)');
check('Array.from({length:4},(_,i)=>state.ingredients.filter(n=>n.owner===i).map(n=>NAT.indexOf(n.midi))).every(a=>Math.abs(a[1]-a[0])===1)');
run("config={players:4,mode:'normal',seconds:180,display:'sol'};startRound()");
check('Array.from({length:4},(_,i)=>state.ingredients.filter(n=>n.owner===i).map(n=>NAT.indexOf(n.midi))).every(a=>a.length===3&&a[0]<4&&a[1]>=4&&a[1]<8&&a[2]>=8)');
}
check("new Set(Array.from({length:30},()=>JSON.stringify(distribute(pool(4,'easy'),4,'easy')))).size>1");
check("Array.from({length:100},()=>pool(3,'easy')).every(p=>p.every(m=>m>=60&&m<=72)&&p.at(-1)-p[0]<=9)");
run("config={players:4,mode:'hard',seconds:180,display:'sol'};startRound();beginTrading()");
check("!$('recipeSheet').innerHTML.includes('data-staff-midi')");
run('globalThis.hintId=state.active;showRecipe()');check('current().hinted&&current().recipeOpen');
check("$('recipeSheet').innerHTML.includes('data-staff-midi')&&!$('recipeSheet').innerHTML.includes('<sub>')");
run('showRecipe()');check('current().hinted&&!current().recipeOpen');
run('selectOrder(state.orders[1].id)');check('!current().hinted&&!current().recipeOpen');
run('selectOrder(hintId);$("clear").onclick()');check('current().hinted');
run('current().heard=true;current().built=[...current().answer];globalThis.base=orderPoints({...current(),attempts:1,hinted:false},1,performance.now());globalThis.hintedExpected=Math.round(base*.7);submit()');
check('state.score===hintedExpected&&state.combo===1&&state.success===1');
run('choose(state.ingredients[0].midi);add()');check('state.selected===null&&current().built.length===1');run('add()');check('current().built.length===1');
check('staffPosition(60).y===88&&staffPosition(64).y===76&&staffPosition(67).y===64&&staffPosition(69).y===58&&staffPosition(76).y===34');
check('staffPosition(61).sharp&&staffPosition(61).y===staffPosition(60).y');
check('NOTES.every(n=>{const p=staffPosition(n.midi);return p.y>=28&&p.y<=100})');
check("recipeSVG([57,60,61,76]).includes('data-staff-midi=\"61\"')");
console.log(`PASS: ${checks} assertions; 1500 generated orders across all 15 valid configurations. DOM and AudioContext are mocked; no browser/device rendering or audible test claimed.`);
})().catch(e=>{console.error(e);process.exit(1)});
