import {initializeApp} from 'firebase/app';
import {getAuth,setPersistence,browserSessionPersistence,signInAnonymously} from 'firebase/auth';
import {getDatabase,ref,get,set,update,remove,onValue,onDisconnect,runTransaction,serverTimestamp} from 'firebase/database';

/* One immutable request per device. Only the host can commit the private referee state. */
class RoomClient{
 constructor(config,game){this.config=config;this.Game=game;this.off=[];this.connected=false;this.members={};this.presence={};this.seats={};this.offset=0;this.seq=Date.now()*1000;this.lastAudio='';this.pumping=false;}
 now(){return Date.now()+this.offset;}
 async init(){if(this.uid)return;const app=initializeApp(this.config,'rainbow-v22');const auth=getAuth(app);await setPersistence(auth,browserSessionPersistence);await auth.authStateReady();this.uid=(auth.currentUser||(await signInAnonymously(auth)).user).uid;this.db=getDatabase(app);this.off.push(onValue(ref(this.db,'.info/serverTimeOffset'),s=>this.offset=s.val()||0));this.off.push(onValue(ref(this.db,'.info/connected'),s=>{this.connected=!!s.val();this.onConnection?.(this.connected);if(this.connected&&this.code)this.markPresence().catch(e=>this.onError?.(e));}));}
 path(p=''){return ref(this.db,'roomsV22/'+this.code+(p?'/'+p:''));}
 async create(config,count){await this.init();if(!this.Game.validConfig(config))throw Error('人數或難度超過音域容量');if(count>config.players)throw Error('本機人數超過房間總人數');
 const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789',bytes=crypto.getRandomValues(new Uint8Array(6));this.code=[...bytes].map(n=>alphabet[n%alphabet.length]).join('');this.hostUid=this.uid;
 const now=this.now(),game=this.Game.initial(config,crypto.getRandomValues(new Uint32Array(1))[0]);game.lastHostAt=now;this.expiresAt=now+7190000;
 const member={device:0,count,first:0,second:count===2?1:-1,joinedAt:now,readyRound:'none'},seats={0:this.uid};if(count===2)seats[1]=this.uid;
 const room={meta:{hostUid:this.uid,createdAt:now,expiresAt:now+7190000,config,version:'2.2'},members:{[this.uid]:member},seats,deviceSlots:{0:this.uid},authority:{revision:0,game:JSON.stringify(game)},public:this.pack(game)};
 this.roomConfig=config;await set(this.path(),room);await this.attach();return this.code;
 }
 pack(game){return {phase:game.phase,roundId:game.roundId,revision:game.revision,snapshot:JSON.stringify(this.Game.publicState(game)),hostBeat:game.lastHostAt||this.now()};}
 async join(code,count){await this.init();code=code.trim().toUpperCase();if(!/^[A-HJ-NP-Z2-9]{6}$/.test(code))throw Error('請輸入六碼房間代號');this.code=code;
 const meta=(await get(this.path('meta'))).val();if(!meta||meta.expiresAt<=this.now())throw Error('房間不存在或已過期');this.hostUid=meta.hostUid;this.expiresAt=meta.expiresAt;this.roomConfig=meta.config;
 const existing=(await get(this.path('members/'+this.uid)).catch(()=>null))?.val();
 if(!existing){const seats=(await get(this.path('seats'))).val()||{},devices=(await get(this.path('deviceSlots'))).val()||{},device=[0,1,2,3].find(i=>!devices[i]),free=Array.from({length:meta.config.players},(_,i)=>i).filter(i=>!seats[i]);if(device===undefined)throw Error('房間最多四台裝置');if(free.length<count)throw Error('剩餘廚師位置不足');
  const first=free[0],second=count===2?free[1]:-1,changes={['members/'+this.uid]:{device,count,first,second,joinedAt:this.now(),readyRound:'none'},['deviceSlots/'+device]:this.uid,['seats/'+first]:this.uid};if(second>=0)changes['seats/'+second]=this.uid;await update(this.path(),changes);}
 await this.attach();
 }
 async attach(){this.host=this.uid===this.hostUid;
 const [members,seats,presence]=await Promise.all(['members','seats','presence'].map(p=>get(this.path(p))));this.members=members.val()||{};this.seats=seats.val()||{};this.presence=presence.val()||{};
 sessionStorage.setItem('rainbow-v22-room',JSON.stringify({code:this.code,uid:this.uid}));
 const watch=(p,fn)=>this.off.push(onValue(this.path(p),s=>fn(s.val()),e=>{if(/permission|denied/i.test(String(e?.message))&&!this.closed){this.closed=true;this.onClosed?.();}else if(!this.closed)this.onError?.(e);}));
 watch('members',v=>{this.members=v||{};this.onRoster?.();});watch('presence',v=>{this.presence=v||{};this.onRoster?.();});watch('seats',v=>{this.seats=v||{};this.onRoster?.();});
 watch('public',v=>{if(!v){this.onClosed?.();return;}try{this.public=v;this.game=this.Game.sanitizePublic(JSON.parse(v.snapshot),this.roomConfig);this.onState?.(this.game);}catch(e){this.onError?.(e);}});
 watch('receipts/'+this.uid,v=>{this.receipt=v;if(v)this.seq=Math.max(this.seq,v.seq);this.settlePending();});
 watch('requests/'+this.uid,v=>{this.ownRequest=v;this.settlePending();});
 if(this.host){watch('requests',v=>{this.requests=v||{};this.pump();});watch('authority',v=>{this.authority=v;});this.hostTimer=setInterval(()=>this.heartbeat(),2000);}
 this.expiryTimer=setTimeout(()=>{this.onError?.(Error('房間已到兩小時期限，請重新開房'));this.disconnect();},Math.max(0,this.expiresAt-this.now()));
 await this.markPresence();
 const saved=sessionStorage.getItem('rainbow-v22-pending');if(saved){try{const cmd=JSON.parse(saved);if(cmd.code===this.code){delete cmd.code;this.pending=cmd;this.onPending?.(true);const receipt=(await get(this.path('receipts/'+this.uid))).val();if(receipt?.id===cmd.id){this.pending=null;sessionStorage.removeItem('rainbow-v22-pending');this.onPending?.(false);}else if(!(await get(this.path('requests/'+this.uid))).exists()){this.pending=null;sessionStorage.removeItem('rainbow-v22-pending');this.onPending?.(false);this.onError?.(Error('未完成的操作已取消，請確認料理後重新操作'));}}}catch{sessionStorage.removeItem('rainbow-v22-pending');}}
 }
 settlePending(){const v=this.receipt;if(!v||this.ownRequest!==null||this.pending?.id!==v.id)return;const pending=this.pending;this.pending=null;sessionStorage.removeItem('rainbow-v22-pending');this.onPending?.(false);if(v.result==='ok')pending.resolve?.(v);else pending.reject?.(Error(v.result));}
 async markPresence(){if(!this.code||!this.uid||!this.connected||!this.members[this.uid])return;await onDisconnect(this.path('presence/'+this.uid)).set({connected:false,seenAt:serverTimestamp()});await set(this.path('presence/'+this.uid),{connected:true,seenAt:serverTimestamp()});}
 owns(owner){const m=this.members[this.uid];return !!m&&(m.first===owner||m.second===owner);}
 hostAvailable(){return this.connected&&!!this.presence[this.hostUid]?.connected&&!!this.public&&this.now()-this.public.hostBeat<10000;}
 async ready(roundId){if(!this.connected)throw Error('網路尚未連線');await set(this.path('members/'+this.uid+'/readyRound'),roundId);}
 command(type,orderId=-1,midi=-1,orderRevision=0){if(!this.hostAvailable())return Promise.reject(Error('等待房主裝置恢復連線'));if(this.pending)return Promise.reject(Error('上一個操作仍在同步，請稍候'));
  const cmd={id:crypto.randomUUID(),seq:this.seq=Math.max(this.seq+1,Date.now()*1000),uid:this.uid,type,roundId:this.game?.roundId||'lobby',orderId,midi,orderRevision,createdAt:this.now()};
  return new Promise((resolve,reject)=>{this.pending={...cmd,resolve,reject};sessionStorage.setItem('rainbow-v22-pending',JSON.stringify({...cmd,code:this.code}));this.onPending?.(true);set(this.path('requests/'+this.uid),cmd).catch(e=>{if(this.pending?.id===cmd.id){this.pending=null;sessionStorage.removeItem('rainbow-v22-pending');this.onPending?.(false);reject(e);}});});
 }
 context(){return {hostUid:this.hostUid,members:this.members,seats:this.seats,presence:this.presence};}
 async publish(a,cmd){this.authority=a;const game=JSON.parse(a.game),changes={public:this.pack(game)};if(cmd){const receipt=a.processed?.[cmd.uid];if(receipt)changes['receipts/'+cmd.uid]=receipt.id===cmd.id?receipt:{id:cmd.id,seq:cmd.seq,result:'較舊的操作已忽略，請確認目前料理',revision:a.revision};}await update(this.path(),changes);if(cmd)await runTransaction(this.path('requests/'+cmd.uid),r=>r?.id===cmd.id?null:undefined,{applyLocally:false});}
 async pump(){if(!this.host||this.pumping||!this.connected)return;this.pumping=true;try{
  for(const cmd of Object.values(this.requests||{}).sort((a,b)=>a.createdAt-b.createdAt||a.id.localeCompare(b.id))){
   const context=this.context(),now=this.now();const result=await runTransaction(this.path('authority'),a=>a?this.Game.transact(a,cmd,context,now):a,{applyLocally:false});
   if(result.committed&&result.snapshot.exists())await this.publish(result.snapshot.val(),cmd);
  }
 }catch(e){this.onError?.(e);}finally{this.pumping=false;if(Object.keys(this.requests||{}).length&&this.code)queueMicrotask(()=>this.pump());}}
 async heartbeat(){if(!this.host||!this.connected||this.pumping||(typeof document!=='undefined'&&document.hidden))return;this.pumping=true;try{const now=this.now(),context=this.context();const result=await runTransaction(this.path('authority'),a=>{if(!a)return a;const game=JSON.parse(a.game),r=this.Game.reduce(game,{uid:this.uid,type:'tick'},context,now);return {...a,revision:r.game.revision,game:JSON.stringify(r.game)};},{applyLocally:false});if(result.committed&&result.snapshot.exists())await this.publish(result.snapshot.val());}catch(e){this.onError?.(e);}finally{this.pumping=false;this.pump();}}
 async leave(){if(!this.code)return;if(this.host){await remove(this.path());}else if(this.game?.phase==='lobby'){const m=this.members[this.uid],changes={['members/'+this.uid]:null,['presence/'+this.uid]:null};if(m){changes['seats/'+m.first]=null;changes['deviceSlots/'+m.device]=null;if(m.second>=0)changes['seats/'+m.second]=null;}await update(this.path(),changes);}else{await set(this.path('presence/'+this.uid),{connected:false,seenAt:serverTimestamp()});}sessionStorage.removeItem('rainbow-v22-room');sessionStorage.removeItem('rainbow-v22-pending');this.disconnect();}
 disconnect(){for(const off of this.off)off();this.off=[];clearInterval(this.hostTimer);clearTimeout(this.expiryTimer);this.code=null;}
}
window.KitchenRoomClient=RoomClient;
export {RoomClient};
