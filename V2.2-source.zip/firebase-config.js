/* Firebase browser configuration supplied by the project owner; not an Admin credential. */
window.KITCHEN_FIREBASE_CONFIG={
 apiKey:'AIzaSyAAfKi1718e76cC37kVjLbgXxYYGUtA7fM',
 authDomain:'music-rainbow-kitchen-6c7fd.firebaseapp.com',
 projectId:'music-rainbow-kitchen-6c7fd',
 storageBucket:'music-rainbow-kitchen-6c7fd.firebasestorage.app',
 messagingSenderId:'39406003138',
 appId:'1:39406003138:web:2a4622781fd941f283ec5b',
 databaseURL:'https://music-rainbow-kitchen-6c7fd-default-rtdb.asia-southeast1.firebasedatabase.app/'
};
