/* Independent gain buses: music stays quietly continuous during notes. */
(function(root){
'use strict';
let ctx,notes,music,source,media,active=false;
let musicLevel=.08,noteLevel=.8,musicMuted=false,noteMuted=false;
const $=id=>document.getElementById(id);
function allowed(){return active&&!document.hidden;}
function status(text){$('musicStatus').textContent=text;}
function ramp(target,seconds=.16){if(!music)return;const p=music.gain,t=ctx.currentTime;if(p.cancelAndHoldAtTime)p.cancelAndHoldAtTime(t);else{const value=p.value;p.cancelScheduledValues(t);p.setValueAtTime(value,t);}p.linearRampToValueAtTime(target,t+seconds);}
function apply(){if(notes){notes.gain.setValueAtTime(noteMuted?0:noteLevel,ctx.currentTime);ramp(allowed()&&!musicMuted?musicLevel:0);}status(noteMuted||noteLevel===0?'遊戲聲音已靜音，聽音前請開啟':!allowed()?'背景音樂已暫停':musicMuted||musicLevel===0?'背景音樂已靜音':'背景音樂以低音量持續播放');}

function init(context){if(ctx)return;ctx=context;notes=ctx.createGain();notes.gain.setValueAtTime(noteLevel,ctx.currentTime);notes.connect(ctx.destination);music=ctx.createGain();music.gain.setValueAtTime(0,ctx.currentTime);music.connect(ctx.destination);media=$('backgroundMusic');source=ctx.createMediaElementSource(media);source.connect(music);media.addEventListener('error',()=>status('背景音樂無法載入，仍可繼續聽音遊戲。'));apply();}
function unlock(){if(!media||document.hidden)return;const promise=media.play();if(promise?.then)promise.then(()=>{if(!allowed())media.pause();}).catch(()=>status('背景音樂尚未啟動，請再點音量或食材；遊戲聲音仍可使用。'));}
function setActive(value){active=value;if(!active){ramp(0,.03);media?.pause();}else{unlock();apply();}}
function open(){const panel=$('soundPanel');panel.classList.remove('hidden');for(const id of ['soundSetup','soundPrep','soundGame'])$(id).setAttribute('aria-expanded','true');unlock();}
function close(){ $('soundPanel').classList.add('hidden');for(const id of ['soundSetup','soundPrep','soundGame'])$(id).setAttribute('aria-expanded','false');}
for(const id of ['soundSetup','soundPrep','soundGame']){$(id).onclick=open;$(id).setAttribute('aria-controls','soundPanel');$(id).setAttribute('aria-expanded','false');}
$('soundClose').onclick=close;
$('musicVolume').oninput=e=>{musicLevel=Number(e.target.value)/100;$('musicValue').textContent=Math.round(musicLevel*100)+'%';apply();};
$('gameVolume').oninput=e=>{noteLevel=Number(e.target.value)/100;$('gameValue').textContent=Math.round(noteLevel*100)+'%';apply();};
$('musicMute').onclick=()=>{musicMuted=!musicMuted;$('musicMute').setAttribute('aria-pressed',String(musicMuted));$('musicMute').textContent=musicMuted?'開啟':'靜音';apply();};
$('gameMute').onclick=()=>{noteMuted=!noteMuted;$('gameMute').setAttribute('aria-pressed',String(noteMuted));$('gameMute').textContent=noteMuted?'開啟':'靜音';apply();};
document.addEventListener('keydown',e=>{if(e.key==='Escape')close();});
root.KitchenMixer={init,unlock,setActive,noteOutput:()=>notes,isMuted:()=>noteMuted||noteLevel===0};
})(globalThis);
