const fs=require('fs'),vm=require('vm'),assert=require('assert');
let events=[],plays=0,pauses=0;const els=new Map();
function el(k){if(!els.has(k))els.set(k,{textContent:'',classList:{add(){},remove(){}},setAttribute(){},addEventListener(){},play(){plays++;return Promise.resolve()},pause(){pauses++}});return els.get(k);}
const buses=[],ctx={currentTime:10,destination:{},createGain(){const gain={value:0,setValueAtTime(v,t){this.value=v;events.push([this,v,t])},linearRampToValueAtTime(v,t){this.value=v;events.push([this,v,t])},cancelAndHoldAtTime(){},cancelScheduledValues(){}};const bus={gain,connect(){}};buses.push(bus);return bus},createMediaElementSource(){return {connect(){}}}};
const doc={getElementById:el,addEventListener(){},hidden:false};const c=vm.createContext({document:doc,console});vm.runInContext(fs.readFileSync(__dirname+'/mixer.js','utf8'),c);const mix=c.KitchenMixer;
mix.init(ctx);mix.setActive(true);assert(plays>0);assert.equal(buses[1].gain.value,.08);const notes=mix.noteOutput();assert.equal(notes.gain.value,.8);
// Repeated user sound activation must never attenuate or pause the playing background.
let beforePauses=pauses;for(let i=0;i<25;i++){mix.unlock();notes.gain.setValueAtTime(.8,ctx.currentTime);}assert.equal(buses[1].gain.value,.08);assert.equal(pauses,beforePauses);
el('gameVolume').oninput({target:{value:'25'}});assert.equal(notes.gain.value,.25);assert.equal(buses[1].gain.value,.08);
el('gameMute').onclick();assert.equal(notes.gain.value,0);assert.equal(buses[1].gain.value,.08);assert(mix.isMuted());el('gameMute').onclick();assert.equal(notes.gain.value,.25);
el('musicVolume').oninput({target:{value:'15'}});assert.equal(buses[1].gain.value,.15);assert.equal(notes.gain.value,.25);
el('musicMute').onclick();assert.equal(buses[1].gain.value,0);assert.equal(notes.gain.value,.25);el('musicMute').onclick();assert.equal(buses[1].gain.value,.15);
mix.setActive(false);assert(pauses>0);assert.equal(buses[1].gain.value,0);mix.setActive(true);assert.equal(buses[1].gain.value,.15);doc.hidden=true;mix.setActive(true);assert.equal(buses[1].gain.value,0);
console.log('PASS: continuous background playback, independent volume/mute and pause/visibility controls (mock audio).');
