/* VexFlow 4.2.5 embeds standard music glyph outlines. No network/font loading. */
(function(root){
'use strict';
const cache=new Map();
function spelling(m){const letters=['c','c','d','d','e','f','f','g','g','a','a','b'],pc=m%12,oct=Math.floor(m/12)-1;return {key:letters[pc]+'/'+oct,sharp:[1,3,6,8,10].includes(pc)};}
function render(answer){const key=answer.join(',');if(cache.has(key))return cache.get(key);
 const {Renderer,Stave,StaveNote,Accidental,Voice,Formatter,Barline}=root.Vex.Flow;
 const host=document.createElement('div'),width=125+answer.length*65;
 const renderer=new Renderer(host,Renderer.Backends.SVG);renderer.resize(width,170);const context=renderer.getContext();
 const stave=new Stave(10,30,width-20);stave.setBegBarType(Barline.type.NONE).setEndBarType(Barline.type.NONE).addClef('treble').setContext(context).draw();
 // Without barlines, explicitly cancel a previous sharp on the same staff position.
 const alterations=new Map();
 const notes=answer.map(m=>{const p=spelling(m),note=new StaveNote({clef:'treble',keys:[p.key],duration:'q',auto_stem:true});
  if(p.sharp)note.addModifier(new Accidental('#'),0);else if(alterations.get(p.key))note.addModifier(new Accidental('n'),0);
  alterations.set(p.key,p.sharp);return note;});
 const voice=new Voice({num_beats:answer.length,beat_value:4}).addTickables(notes);
 new Formatter().joinVoices([voice]).formatToStave([voice],stave);voice.draw(context,stave);
 const svg=host.querySelector('svg');svg.removeAttribute('style');svg.setAttribute('viewBox',`0 25 ${width} 130`);svg.setAttribute('width','100%');svg.setAttribute('height','100%');svg.setAttribute('role','img');svg.setAttribute('aria-label','高音譜號食譜，依序辨認四分音符的音高');svg.setAttribute('data-notation-engine','VexFlow 4.2.5');svg.setAttribute('preserveAspectRatio','xMidYMid meet');
 notes.forEach((note,i)=>{const group=host.querySelectorAll('.vf-stavenote')[i];if(group){group.setAttribute('data-staff-midi',String(answer[i]));group.setAttribute('data-note-y',String(note.getYs()[0]));group.setAttribute('data-stem-direction',String(note.getStemDirection()));}});
 const result=svg.outerHTML;if(cache.size>=100)cache.delete(cache.keys().next().value);cache.set(key,result);return result;
}
root.KitchenNotation={render,spelling};
})(globalThis);
