const {JSDOM}=require('jsdom'),fs=require('fs'),assert=require('assert');
const dom=new JSDOM('<!doctype html><html><body></body></html>',{runScripts:'outside-only'});
for(const file of ['vendor/vexflow.js','notation.js'])dom.window.eval(fs.readFileSync(__dirname+'/'+file,'utf8'));
const api=dom.window.KitchenNotation;let count=0;const check=(value,message)=>{assert(value,message);count++;};
function parse(ms){return new JSDOM(api.render(ms)).window.document;}
// Fixed reference staff positions from A3 through E5, in VexFlow's default 10px spaces.
const expected=[130,130,125,120,120,115,115,110,105,105,100,100,95,95,90,85,85,80,80,75];
for(let m=57;m<=76;m++){
 const doc=parse([m,m]),notes=[...doc.querySelectorAll('[data-staff-midi]')];
 check(notes.length===2,'all notes rendered');check(notes.every(n=>+n.dataset.noteY===expected[m-57]),'reference staff position '+m);
 check(notes.every(n=>+n.dataset.stemDirection===(expected[m-57]>=95?1:-1)),'stem direction '+m);
 check(doc.querySelectorAll('.vf-clef path').length>0,'standard glyph outline exists');
 check(!doc.querySelector('text'),'no fallback music font or answer labels');
}
// Inspect actual Accidental objects while preserving the full VexFlow renderer.
const original=dom.window.Vex.Flow.Accidental;let seen=[];
// VexFlow's export is read-only. Compare rendered natural cancellation against no-cancellation.
let sharpThenNatural=api.render([61,60]),natural=api.render([60,60]);
check(sharpThenNatural.length>natural.length,'sharp and cancellation glyphs increase outline content');
check(parse([57,60,64,67,76]).querySelectorAll('[data-staff-midi]').length===5,'five-note recipe with ledger lines');
check(api.render([57,60,64,67,76])===api.render([57,60,64,67,76]),'cached result stable');
check(!api.render([57,60]).includes('M35 91 C56'),'hand-drawn clef removed');
check(!api.render([57,60]).includes('<image'),'notation uses vector glyphs');
fs.writeFileSync(__dirname+'/notation-qa.svg',api.render([57,60,61,60,76]));
console.log(`PASS: ${count} notation assertions using real VexFlow and a DOM implementation; A3–E5 positions, stems, glyph paths, ledger notes and no text labels.`);
