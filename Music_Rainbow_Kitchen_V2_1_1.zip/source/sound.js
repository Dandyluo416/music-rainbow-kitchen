/* Original deterministic instrument synthesis. No downloads, samples or dependencies. */
(function(root){
'use strict';
const instruments=[
 {name:'木琴',h:[1,.14,.35,.08,.12],attack:.004,decay:6,bright:8},
 {name:'長笛',h:[1,.09,.025],attack:.10,decay:.25,vibrato:.0015},
 {name:'單簧管',h:[1,0,.64,0,.32,0,.12],attack:.065,decay:.3},
 {name:'豎琴',h:[1,.65,.38,.22,.12,.07],attack:.008,decay:3.7,bright:4},
 {name:'弦樂',h:[1,.52,.33,.24,.17,.12,.08,.05],attack:.16,decay:.15,vibrato:.002},
 {name:'玻璃琴',h:[1,.035,.3,.015,.18,.01,.1],attack:.006,decay:1.7,bright:.3},
 {name:'手風琴',h:[1,.55,.12,.3,.07,.15],attack:.05,decay:.2,tremolo:.12},
 {name:'吉他',h:[1,.7,.36,.18,.1,.06],attack:.012,decay:2.5,bright:6},
 {name:'管風琴',h:[1,.8,.07,.4,.02,.01,.015,.2],attack:.035,decay:.05},
 {name:'巴松管',h:[1,.25,.7,.4,.2,.25,.1],attack:.09,decay:.4,bright:1},
 {name:'顫音琴',h:[1,.1,.22,.04,.08],attack:.007,decay:1.5,tremolo:.45},
 {name:'柔和鋼琴',h:[1,.48,.23,.13,.07,.035,.02],attack:.012,decay:2.1,bright:3}
];
const natural=[57,59,60,62,64,65,67,69,71,72,74,76];
function instrument(m,mode){return mode==='easy'?Math.max(0,natural.indexOf(m)):11;}
function synth(m,index,rate=22050){
 const p=instruments[index],f=440*2**((m-69)/12),duration=.83,a=new Float32Array(Math.ceil(rate*duration));
 let phase=0,sum=0,peak=0;
 for(let i=0;i<a.length;i++){
  const t=i/rate;phase+=2*Math.PI*f/rate*(1+(p.vibrato||0)*Math.sin(2*Math.PI*5.2*t)*Math.min(1,t/.25));
  let x=0;for(let h=0;h<p.h.length;h++)if(f*(h+1)<rate*.45)x+=p.h[h]*Math.sin(phase*(h+1))*Math.exp(-(p.bright||0)*h*t*.35);
  const attack=Math.sin(Math.min(1,t/p.attack)*Math.PI/2)**2;
  const release=t>.57?Math.cos(Math.min(1,(t-.57)/.26)*Math.PI/2)**2:1;
  x*=attack*release*Math.exp(-p.decay*t)*(1-(p.tremolo||0)*(.5+.5*Math.cos(2*Math.PI*5*t)));
  a[i]=x;sum+=x*x;peak=Math.max(peak,Math.abs(x));
 }
 const scale=Math.min(.15/Math.sqrt(sum/a.length),.65/peak);for(let i=0;i<a.length;i++)a[i]*=scale;
 return a;
}
const api={instruments,instrument,synth};root.KitchenSound=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
